﻿const fs = require('fs')
const path = require('path')
const { PrismaClient } = require('@prisma/client')

const sourceName = process.env.SOURCE_NAME
const dbUrl = process.env.SOURCE_DB_URL
const outDir = process.env.OUT_DIR

const prisma = new PrismaClient({ datasources: { db: { url: dbUrl } } })

const parseSchema = (value) => {
  if (!value) return { sections: [] }
  if (typeof value === 'object') return value
  try { return JSON.parse(value) } catch { return { raw: value, sections: [] } }
}

;(async () => {
  const [
    questionBank,
    customerQuestions,
    products,
    customers,
    users,
    profileShares,
    formSchemas,
    passportProducts,
    passportCustomQuestions,
    passportSectionResponses,
  ] = await Promise.all([
    prisma.questionBank.findMany({ orderBy: [{ id: 'asc' }] }),
    prisma.customerQuestion.findMany({ orderBy: [{ id: 'asc' }] }),
    prisma.product.findMany({ orderBy: [{ id: 'asc' }] }),
    prisma.customer.findMany({ orderBy: [{ id: 'asc' }] }),
    prisma.user.findMany({ orderBy: [{ id: 'asc' }] }),
    prisma.profileShare.findMany({ orderBy: [{ id: 'asc' }] }),
    prisma.formSchema.findMany({ orderBy: [{ id: 'asc' }] }),
    prisma.passportProductInstance.findMany({ orderBy: [{ createdAt: 'asc' }] }),
    prisma.passportCustomQuestion.findMany({ orderBy: [{ createdAt: 'asc' }] }),
    prisma.passportSectionResponse.findMany({ orderBy: [{ createdAt: 'asc' }] }),
  ])

  const sectionMappings = products.map((p) => ({
    productId: p.id,
    productName: p.name,
    slug: p.slug,
    formSchema: parseSchema(p.formSchema),
  }))

  const payload = {
    source: sourceName,
    generatedAt: new Date().toISOString(),
    summary: {
      systemQuestions: questionBank.filter((q) => q.source === 'SYSTEM').length,
      customerQuestions: customerQuestions.length,
      products: products.length,
      sectionsFromProducts: sectionMappings.reduce((n, p) => n + (Array.isArray(p.formSchema?.sections) ? p.formSchema.sections.length : 0), 0),
      clients: customers.length,
      users: users.length,
      profileShares: profileShares.length,
      passportProducts: passportProducts.length,
      passportCustomQuestions: passportCustomQuestions.length,
      passportSectionResponses: passportSectionResponses.length,
    },
    questions: {
      questionBank,
      customerQuestions,
    },
    products,
    sections: {
      productSectionMappings: sectionMappings,
      formSchemas,
    },
    inputTypesAndTooltips: questionBank.map((q) => ({
      id: q.id,
      text: q.text,
      inputType: q.inputType,
      selectOptions: q.selectOptions,
      helperText: q.helperText,
      source: q.source,
      productId: q.productId,
    })),
    clients: {
      users,
      customers,
      profileShares,
    },
    formsFilled: {
      passportProducts,
      passportCustomQuestions,
      passportSectionResponses,
    },
  }

  fs.writeFileSync(path.join(outDir, 'structured-export.json'), JSON.stringify(payload, null, 2))
  fs.writeFileSync(path.join(outDir, 'summary.json'), JSON.stringify(payload.summary, null, 2))

  await prisma.$disconnect()
})().catch(async (err) => {
  console.error(err)
  try { await prisma.$disconnect() } catch {}
  process.exit(1)
})
